﻿

namespace BookStore_Models.Models.Requests
{
    public class TestRequest
    {
        public int Id { get; set; }

        public string ?Name { get; set; }

        public DateTime ReleaseDate { get; set; }
    }
}
