﻿using System;

public class GetAllBookByAuthorRequest
{
	public int AuthorId { get; set; }
	public DateTime AfterDate {get; set;}

}
