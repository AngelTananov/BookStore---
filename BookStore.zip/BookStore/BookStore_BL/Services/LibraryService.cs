﻿using BookStore_DL.Interfaces;

namespace BookStore_BL.Services
{
    internal class LibraryService : ILibraryService
    {
        private readonly LibraryService _libraryService;

        public LibraryService(LibraryService libraryService)
        {
            _libraryService = libraryService;
        }

        public string GetLibraryName()
        {
            throw new NotImplementedException();
        }
    }
}