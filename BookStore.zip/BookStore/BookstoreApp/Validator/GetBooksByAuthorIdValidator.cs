﻿using System.Data;
using FluentValidation;
using FluentValidation.AspNetCore;

namespace BookstoreApp.Validator
{
    public class GetBooksByAuthorIdValidator
    {
        public GetBooksByAuthorIdValidator()
        {
            
        }
    }
}
