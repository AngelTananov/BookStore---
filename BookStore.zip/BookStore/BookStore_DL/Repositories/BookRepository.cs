﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookStore_Models.Models;
using BookStore_DL.Interfaces;
using BookStore_DL.MemoryDB;

namespace BookStore_DL.Repositories
{
    public class BookRepository : IBookRepository
    {
        public void Add(Book book)
        {
            InMemoryDB.BookData.Add(book);
        }

        public void Delete(int id)
        {
            var book = GetById(id);
            if (book != null)
            {
                InMemoryDB.BookData.Remove(book);
            }

        }

        public List<Book> GetAll()
        {
            return InMemoryDB.BookData;
        }

        public Book? GetById(int id)
        {
            return InMemoryDB.BookData.FirstOrDefault(a => a.Id == id);
        }



    }
}
